TESTING = True

DATABASE = '../../instance/test_db.sqlite'