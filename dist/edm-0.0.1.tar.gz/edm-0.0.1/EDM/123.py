from werkzeug.security import check_password_hash, generate_password_hash

print(generate_password_hash("123"))